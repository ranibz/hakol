# כלי כיול בוחנים – פרויקט למ"ד בתקשורת

כלי אינטרנטי לכיול בוחנים בפרויקט למ"ד (עבודת גמר) בתקשורת.

## מה זה עושה?
- **מנחה** מגדיר מחוון + עבודת תלמיד/ה
- **כל בוחן/ת** נכנס מהמחשב שלו, רואה את דרישות המחוון, ונותן ציון והערות
- **המנחה** רואה בזמן אמת השוואה בין כל הבוחנים עם גרפים וניתוח סטטיסטי
- **סימולציה** — אפשר להריץ 5 בוחנים מדומים עם אופי שונה

## התקנה והעלאה

### דרישות
- חשבון Google
- [Node.js](https://nodejs.org) מותקן

### שלבים

1. **צרו פרויקט Firebase** ב-[console.firebase.google.com](https://console.firebase.google.com)

2. **צרו Realtime Database**: Build → Realtime Database → Create → Start in test mode

3. **פתחו Rules**: בלשונית Rules הדביקו:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

4. **התקינו Firebase CLI**:
```bash
npm install -g firebase-tools
firebase login
```

5. **העלו**:
```bash
firebase deploy
```

6. **שלחו את הקישור** `https://tester-2e95d.web.app` לבוחנים

## מבנה
```
index.html      ← האפליקציה (קובץ יחיד)
firebase.json   ← הגדרות hosting
.firebaserc     ← הפרויקט ב-Firebase
```
